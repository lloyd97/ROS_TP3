
"use strict";

let udm_service = require('./udm_service.js')

module.exports = {
  udm_service: udm_service,
};
