// Auto-generated. Do not edit!

// (in-package udm_hand_control.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class udm_serviceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.joint_goal1 = null;
      this.joint_goal2 = null;
      this.joint_goal3 = null;
      this.group = null;
    }
    else {
      if (initObj.hasOwnProperty('joint_goal1')) {
        this.joint_goal1 = initObj.joint_goal1
      }
      else {
        this.joint_goal1 = new std_msgs.msg.Float32();
      }
      if (initObj.hasOwnProperty('joint_goal2')) {
        this.joint_goal2 = initObj.joint_goal2
      }
      else {
        this.joint_goal2 = new std_msgs.msg.Float32();
      }
      if (initObj.hasOwnProperty('joint_goal3')) {
        this.joint_goal3 = initObj.joint_goal3
      }
      else {
        this.joint_goal3 = new std_msgs.msg.Float32();
      }
      if (initObj.hasOwnProperty('group')) {
        this.group = initObj.group
      }
      else {
        this.group = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type udm_serviceRequest
    // Serialize message field [joint_goal1]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.joint_goal1, buffer, bufferOffset);
    // Serialize message field [joint_goal2]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.joint_goal2, buffer, bufferOffset);
    // Serialize message field [joint_goal3]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.joint_goal3, buffer, bufferOffset);
    // Serialize message field [group]
    bufferOffset = std_msgs.msg.String.serialize(obj.group, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type udm_serviceRequest
    let len;
    let data = new udm_serviceRequest(null);
    // Deserialize message field [joint_goal1]
    data.joint_goal1 = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    // Deserialize message field [joint_goal2]
    data.joint_goal2 = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    // Deserialize message field [joint_goal3]
    data.joint_goal3 = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    // Deserialize message field [group]
    data.group = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.String.getMessageSize(object.group);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'udm_hand_control/udm_serviceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5547483f4c0fc8abe6432210fa61267a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Float32 joint_goal1 
    std_msgs/Float32 joint_goal2 
    std_msgs/Float32 joint_goal3 
    std_msgs/String group
    
    ================================================================================
    MSG: std_msgs/Float32
    float32 data
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new udm_serviceRequest(null);
    if (msg.joint_goal1 !== undefined) {
      resolved.joint_goal1 = std_msgs.msg.Float32.Resolve(msg.joint_goal1)
    }
    else {
      resolved.joint_goal1 = new std_msgs.msg.Float32()
    }

    if (msg.joint_goal2 !== undefined) {
      resolved.joint_goal2 = std_msgs.msg.Float32.Resolve(msg.joint_goal2)
    }
    else {
      resolved.joint_goal2 = new std_msgs.msg.Float32()
    }

    if (msg.joint_goal3 !== undefined) {
      resolved.joint_goal3 = std_msgs.msg.Float32.Resolve(msg.joint_goal3)
    }
    else {
      resolved.joint_goal3 = new std_msgs.msg.Float32()
    }

    if (msg.group !== undefined) {
      resolved.group = std_msgs.msg.String.Resolve(msg.group)
    }
    else {
      resolved.group = new std_msgs.msg.String()
    }

    return resolved;
    }
};

class udm_serviceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.res = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('res')) {
        this.res = initObj.res
      }
      else {
        this.res = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type udm_serviceResponse
    // Serialize message field [res]
    bufferOffset = _serializer.bool(obj.res, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type udm_serviceResponse
    let len;
    let data = new udm_serviceResponse(null);
    // Deserialize message field [res]
    data.res = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'udm_hand_control/udm_serviceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9b4df51719804cbf1b97591437594b37';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool res
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new udm_serviceResponse(null);
    if (msg.res !== undefined) {
      resolved.res = msg.res;
    }
    else {
      resolved.res = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: udm_serviceRequest,
  Response: udm_serviceResponse,
  md5sum() { return '47524c0f2f3d99dd738e611b430df492'; },
  datatype() { return 'udm_hand_control/udm_service'; }
};
